## lab_testing
#### Samantha Ngo & Tal Lavi | CSCI 133 | 2018 September 18 | Hunter Daedalus Honors

##### These files are used to practice implementing and using Catch2 and Makefiles.

Notes:
- We were able to get the makefile to work and compile, but we were unable to understand and fix why the tests would 
not print out in the terminal.
