#pragma once

using std::string;

string piglatinify(string word);
