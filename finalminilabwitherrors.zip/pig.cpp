#include <iostream>
#include <string>
#include "pig.h"

using namespace std;
using std::string;
using std::cout;

string piglatinify(string word){
  std::cout << "CHECKing piglatin" << endl;
  // Code Here
  return "Hello";
}
